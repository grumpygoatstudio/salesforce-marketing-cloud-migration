const mysql = require('mysql');

exports.handler = (event, context) => {
    // console.log('Received event:', JSON.stringify(event, null, 2));
    function sql_insert(event) {
        var conn = mysql.createConnection({
          host     : process.env.MYSQL_HOST,
          user     : process.env.MYSQL_USER,
          password : process.env.MYSQL_PASSWORD,
          database : process.env.MYSQL_DB
        });

        var sql = 'INSERT INTO mobile_uploads (mobile_number, keyword, security_code, body) VALUES ('
            + conn.escape(event["queryStringParameters"]['m']) + ', ' // keyword
            + conn.escape(event["queryStringParameters"]['k']) + ', ' // mobile number
            + conn.escape(event["queryStringParameters"]['s']) + ', ' // security code
            + conn.escape(event["queryStringParameters"]['b']) // body text
            + ');';
        console.log('SQL QUERY BUILT: \n' + sql);
        conn.query(sql, function (error, results, fields) {
            if (error) {
                console.log('Connection error occured.', error.stack);
                context.fail();
            } else {
                console.log('Connection worked as id ' + conn.threadId);
                context.succeed(results);
            }
        });
    }

    switch (event.httpMethod) {
        case 'GET':
            sql_insert(event);
            break;
        default:
            context.fail(`Unsupported method "${event.httpMethod}"`);
    }
};
